import React from 'react';
import { motion } from 'framer-motion';

interface ResultsCardProps {
  analysis: {
    lead_id: string;
    job_id: number;
    status: string;
  };
}
const ResultsCard: React.FC<ResultsCardProps> = ({ analysis }) => (
  <motion.div
    className="bg-white rounded-2xl shadow-lg p-6 space-y-4"
    initial={{ scale: 0.9, opacity: 0 }}
    animate={{ scale: 1, opacity: 1 }}
    transition={{ duration: 0.4 }}
  >
    <h3 className="text-xl font-semibold">Analysis Submitted</h3>
    <div className="grid grid-cols-2 gap-2 text-sm">
      <div>
        <span className="font-medium">Lead ID:</span> {analysis.lead_id}
      </div>
      <div>
        <span className="font-medium">Job ID:</span> {analysis.job_id}
      </div>
      <div className="col-span-2">
        <span className="font-medium">Status:</span>{' '}
        <span
          className={`${
            analysis.status === 'queued_for_processing'
              ? 'text-yellow-600'
              : analysis.status === 'completed'
              ? 'text-green-600'
              : 'text-blue-600'
          }`}
        >
          {analysis.status}
        </span>
      </div>
    </div>
  </motion.div>
);
export default ResultsCard;