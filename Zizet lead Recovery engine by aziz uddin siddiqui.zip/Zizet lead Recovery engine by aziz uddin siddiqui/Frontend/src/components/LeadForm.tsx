import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

interface ConversationEntry {
  role: 'customer' | 'agent';
  message: string;
}
interface LeadFormData {
  tenant_id: string;
  lead_id: string;
  customer: { name: string; phone: string };
  lead: {
    source: string;
    status: string;
    created_at: string;
    last_contacted_at?: string;
  };
  conversation: ConversationEntry[];
}
interface LeadFormProps {
  onSubmit: (data: LeadFormData) => void;
  isLoading?: boolean;
}
const LeadForm: React.FC<LeadFormProps> = ({ onSubmit, isLoading }) => {
  const [formData, setFormData] = useState<LeadFormData>({
    tenant_id: '',
    lead_id: '',
    customer: { name: '', phone: '' },
    lead: { source: 'whatsapp', status: 'contacted', created_at: '' },
    conversation: [{ role: 'customer', message: '' }],
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    if (name.includes('customer.')) {
      const field = name.split('.')[1];
      setFormData((prev) => ({
        ...prev,
        customer: { ...prev.customer, [field]: value },
      }));
    } else if (name.startsWith('lead.')) {
      const field = name.split('.')[1];
      setFormData((prev) => ({
        ...prev,
        lead: { ...prev.lead, [field]: value },
      }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleConversationChange = (idx: number, field: 'role' | 'message', val: string) => {
    setFormData((prev) => {
      const updated = [...prev.conversation];
      updated[idx][field] = val;
      return { ...prev, conversation: updated };
    });
  };

  const addConversationEntry = () => {
    setFormData((prev) => ({
      ...prev,
      conversation: [...prev.conversation, { role: 'customer', message: '' }],
    }));
  };
  const removeConversationEntry = (idx: number) => {
    setFormData((prev) => ({
      ...prev,
      conversation: prev.conversation.filter((_, i) => i !== idx),
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <motion.form
      onSubmit={handleSubmit}
      className="space-y-6 max-w-2xl mx-auto bg-white p-6 rounded-2xl shadow-xl"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <h2 className="text-2xl font-bold mb-4">Lead Analysis Input</h2>

      {/* Tenant & Lead ID */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <motion.div whileFocus={{ scale: 1.02 }}>
          <label className="block text-sm font-medium mb-1">Tenant ID</label>
          <input
            type="text"
            name="tenant_id"
            value={formData.tenant_id}
            onChange={handleChange}
            required
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </motion.div>
        <motion.div whileFocus={{ scale: 1.02 }}>
          <label className="block text-sm font-medium mb-1">Lead ID</label>
          <input
            type="text"
            name="lead_id"
            value={formData.lead_id}
            onChange={handleChange}
            required
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </motion.div>
      </div>

      {/* Customer */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <motion.div whileFocus={{ scale: 1.02 }}>
          <label className="block text-sm font-medium mb-1">Customer Name</label>
          <input
            type="text"
            name="customer.name"
            value={formData.customer.name}
            onChange={handleChange}
            required
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </motion.div>
        <motion.div whileFocus={{ scale: 1.02 }}>
          <label className="block text-sm font-medium mb-1">Phone</label>
          <input
            type="tel"
            name="customer.phone"
            value={formData.customer.phone}
            onChange={handleChange}
            required
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </motion.div>
      </div>

      {/* Lead meta */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <motion.div whileFocus={{ scale: 1.02 }}>
          <label className="block text-sm font-medium mb-1">Source</label>
          <select
            name="lead.source"
            value={formData.lead.source}
            onChange={handleChange}
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="whatsapp">WhatsApp</option>
            <option value="email">Email</option>
            <option value="call">Call</option>
            <option value="form">Form</option>
          </select>
        </motion.div>
        <motion.div whileFocus={{ scale: 1.02 }}>
          <label className="block text-sm font-medium mb-1">Status</label>
          <select
            name="lead.status"
            value={formData.lead.status}
            onChange={handleChange}
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          >
            <option value="new">New</option>
            <option value="contacted">Contacted</option>
            <option value="interested">Interested</option>
            <option value="stopped">Stopped</option>
          </select>
        </motion.div>
        <motion.div whileFocus={{ scale: 1.02 }}>
          <label className="block text-sm font-medium mb-1">Created At</label>
          <input
            type="datetime-local"
            name="lead.created_at"
            value={formData.lead.created_at}
            onChange={handleChange}
            required
            className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </motion.div>
      </div>

      {/* Conversation */}
      <div>
        <label className="block text-sm font-medium mb-2">Conversation</label>
        <AnimatePresence>
          {formData.conversation.map((entry, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="flex gap-2 items-center mb-2"
            >
              <select
                value={entry.role}
                onChange={(e) => handleConversationChange(idx, 'role', e.target.value)}
                className="px-2 py-1 border rounded"
              >
                <option value="customer">Customer</option>
                <option value="agent">Agent</option>
              </select>
              <input
                type="text"
                value={entry.message}
                onChange={(e) => handleConversationChange(idx, 'message', e.target.value)}
                placeholder="Message"
                className="flex-1 px-3 py-2 border rounded-lg"
                required
              />
              <button
                type="button"
                onClick={() => removeConversationEntry(idx)}
                className="text-red-500 hover:text-red-700"
                disabled={formData.conversation.length === 1}
              >
                ✕
              </button>
            </motion.div>
          ))}
        </AnimatePresence>
        <button
          type="button"
          onClick={addConversationEntry}
          className="mt-2 text-indigo-600 hover:underline"
        >
          + Add Conversation Entry
        </button>
      </div>

      <motion.button
        whileTap={{ scale: 0.95 }}
        type="submit"
        disabled={isLoading}
        className="w-full py-3 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition disabled:opacity-50"
      >
        {isLoading ? 'Processing…' : 'Submit Lead'}
      </motion.button>
    </motion.form>
  );
};
export default LeadForm;