import { motion } from 'framer-motion';

const LoadingSpinner: React.FC = () => (
  <motion.div
    className="flex justify-center items-center py-8"
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
  >
    <motion.div
      className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full"
      animate={{ rotate: 360 }}
      transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
    />
  </motion.div>
);
export default LoadingSpinner;