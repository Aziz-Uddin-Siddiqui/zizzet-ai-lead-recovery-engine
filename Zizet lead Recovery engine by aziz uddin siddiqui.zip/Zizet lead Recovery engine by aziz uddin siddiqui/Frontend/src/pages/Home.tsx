import React from 'react';
import { motion } from 'framer-motion';

const Home: React.FC = () => (
  <motion.div
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    transition={{ duration: 0.8 }}
    className="text-center py-12"
  >
    <h1 className="text-4xl font-extrabold mb-4">Zizzet AI Lead Recovery Engine</h1>
    <p className="text-lg text-gray-600 max-w-2xl mx-auto">
      This demo front‑end showcases lead analysis, automated follow‑up generation,
      and webhook processing. Use the navigation above to explore each feature.
    </p>
  </motion.div>
);

export default Home;