import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import LeadForm from '../components/LeadForm';
import { useApi } from '../hooks/useApi';
import ResultsCard from '../components/ResultsCard';
import LoadingSpinner from '../components/LoadingSpinner';
import { motion, AnimatePresence } from 'framer-motion';

interface AnalysisResponse {
  lead_id: string;
  job_id: number;
  status: string;
}

const Analyze: React.FC = () => {
  const [analysis, setAnalysis] = useState<AnalysisResponse | null>(null);
  const { callApi, loading, error } = useApi<AnalysisResponse>();
  const navigate = useNavigate();

  const handleSubmit = async (data: any) => {
    const payload = {
      tenant_id: data.tenant_id,
      lead_id: data.lead_id,
      customer: data.customer,
      lead: data.lead,
      conversation: data.conversation,
    };
    const result = await callApi('/api/v1/leads/analyze', 'POST', payload);
    if (result) {
      setAnalysis(result);
      navigate(`/lead/${result.lead_id}/analysis`);
    }
  };

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold">Lead Analysis</h1>
      <LeadForm onSubmit={handleSubmit} isLoading={loading} />
      <AnimatePresence>
        {loading && (
          <motion.div key="loading" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <LoadingSpinner />
          </motion.div>
        )}
        {error && (
          <motion.div
            key="error"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="bg-red-100 text-red-800 p-4 rounded-lg"
          >
            {error}
          </motion.div>
        )}
        {analysis && (
          <motion.div
            key="results"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
          >
            <ResultsCard analysis={analysis} />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Analyze;