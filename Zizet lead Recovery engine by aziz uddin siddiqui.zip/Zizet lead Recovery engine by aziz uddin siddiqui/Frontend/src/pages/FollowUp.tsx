import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useApi } from '../hooks/useApi';
import LoadingSpinner from '../components/LoadingSpinner';
import ToastNotification from '../components/ToastNotification';
import { motion } from 'framer-motion';

interface FollowUpData {
  lead_id: string;
  follow_up_channel: string;
  follow_up_message: string;
  do_not_contact: boolean;
  phone?: string;
}
const FollowUp: React.FC = () => {
  const { leadId } = useParams<{ leadId: string }>();
  const { callApi, loading, error, data } = useApi<FollowUpData>();
  const [followUp, setFollowUp] = useState<FollowUpData | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const tenantId = 'demo';

  useEffect(() => {
    if (!leadId) return;
    callApi(`/api/v1/leads/${leadId}/analysis?tenant_id=${tenantId}`, 'GET')
      .then((analysis) => {
        setFollowUp({
          lead_id: analysis.lead_id,
          follow_up_channel: analysis.follow_up_channel,
          follow_up_message: analysis.follow_up_message,
          do_not_contact: analysis.do_not_contact,
          phone: analysis.phone || '+1234567890',
        });
      })
      .catch(() => {});
  }, [leadId, callApi]);

  const handleSend = async () => {
    if (!followUp) return;
    try {
      await callApi(`/api/v1/leads/${leadId}/follow-up?tenant_id=${tenantId}`, 'POST', {});
      setToast('Follow‑up sent successfully!');
    } catch {
      setToast('Failed to send follow‑up.');
    }
  };

  return (
    <motion.div
      className="max-w-2xl mx-auto space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <h1 className="text-3xl font-bold">Generate Follow‑up</h1>
      {loading && <LoadingSpinner />}
      {error && <div className="bg-red-100 text-red-800 p-4 rounded-lg">{error}</div>}

      {followUp && (
        <div className="bg-white rounded-2xl shadow-lg p-6 space-y-4">
          <h3 className="text-xl font-semibold">Preview</h3>
          <p><span className="font-medium">Channel:</span> {followUp.follow_up_channel}</p>
          <p><span className="font-medium">Message:</span> {followUp.follow_up_message}</p>
          {followUp.phone && <p><span className="font-medium">Phone:</span> {followUp.phone}</p>}
          <motion.button
            whileTap={{ scale: 0.95 }}
            onClick={handleSend}
            disabled={followUp.do_not_contact}
            className={`px-6 py-2 text-white rounded-lg transition ${
              followUp.do_not_contact
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-indigo-600 hover:bg-indigo-700'
            }`}
          >
            Send Follow‑up
          </motion.button>
          {followUp.do_not_contact && (
            <p className="text-red-600 text-sm">Customer has opted out – follow‑up cannot be sent.</p>
          )}
        </div>
      )}

      {toast && (
        <ToastNotification
          message={toast}
          onClose={() => setToast(null)}
          type="success"
        />
      )}
    </motion.div>
  );
};
export default FollowUp;