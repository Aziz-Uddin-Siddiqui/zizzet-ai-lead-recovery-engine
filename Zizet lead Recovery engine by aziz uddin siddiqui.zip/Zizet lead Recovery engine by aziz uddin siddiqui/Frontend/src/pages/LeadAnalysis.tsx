import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { useApi } from '../hooks/useApi';
import ResultsCard from '../components/ResultsCard';
import LoadingSpinner from '../components/LoadingSpinner';
import { motion } from 'framer-motion';

interface AnalysisData {
  lead_id: string;
  lead_score: number;
  priority: string;
  intent: string;
  stage: string;
  summary: string;
  next_best_action: string;
  follow_up_channel: string;
  follow_up_message: string;
  do_not_contact: boolean;
  phone?: string;
}
const LeadAnalysis: React.FC = () => {
  const { leadId } = useParams<{ leadId: string }>();
  const { callApi, loading, error, data } = useApi<AnalysisData>();
  const [analysis, setAnalysis] = useState<AnalysisData | null>(null);
  const tenantId = 'demo'; // static tenant for demo UI

  useEffect(() => {
    if (!leadId) return;
    callApi(`/api/v1/leads/${leadId}/analysis?tenant_id=${tenantId}`, 'GET')
      .then((result) => setAnalysis({ ...result, phone: result.phone || '+1234567890' }))
      .catch(() => {}); // error already captured by hook
  }, [leadId, callApi]);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold">Lead Analysis Result</h1>
      {loading && <LoadingSpinner />}
      {error && <div className="bg-red-100 text-red-800 p-4 rounded-lg">{error}</div>}
      {analysis && (
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
        >
          <ResultsCard analysis={analysis} />
          <div className="bg-white rounded-2xl shadow-lg p-6 space-y-4">
            <h3 className="text-xl font-semibold">Details</h3>
            <ul className="space-y-2 text-sm">
              <li><span className="font-medium">Score:</span> {analysis.lead_score}</li>
              <li>
                <span className="font-medium">Priority:</span>{' '}
                <span className={`${
                  analysis.priority === 'high' ? 'text-red-600' :
                  analysis.priority === 'medium' ? 'text-yellow-600' :
                  'text-green-600'
                }`}>
                  {analysis.priority}
                </span>
              </li>
              <li><span className="font-medium">Intent:</span> {analysis.intent}</li>
              <li><span className="font-medium">Stage:</span> {analysis.stage}</li>
              <li><span className="font-medium">Next Action:</span> {analysis.next_best_action}</li>
              <li><span className="font-medium">Channel:</span> {analysis.follow_up_channel}</li>
              <li><span className="font-medium">Do Not Contact:</span> {analysis.do_not_contact ? 'Yes' : 'No'}</li>
              <li className="col-span-2">
                <span className="font-medium">Summary:</span>
                <p className="mt-1 text-gray-700">{analysis.summary}</p>
              </li>
            </ul>
            <div className="pt-4">
              <motion.button
                whileTap={{ scale: 0.95 }}
                onClick={() => window.open(`https://wa.me/${analysis.phone}`, '_blank')}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
              >
                Open WhatsApp
              </motion.button>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};
export default LeadAnalysis;