import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useApi } from '../hooks/useApi';
import LoadingSpinner from '../components/LoadingSpinner';

interface WebhookResponse {
  lead_id: string;
  job_id: number;
  status: string;
}
const Webhook: React.FC = () => {
  const { callApi, loading, error, data } = useApi<WebhookResponse>();
  const [form, setForm] = useState({
    tenant_id: 'demo',
    lead_id: '',
    event_id: '',
    customer: { name: '', phone: '' },
    lead: { source: 'form', status: 'new', created_at: '' },
    conversation: [{ role: 'customer', message: '' }],
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    if (name.includes('customer.')) {
      const field = name.split('.')[1];
      setForm((prev) => ({ ...prev, customer: { ...prev.customer, [field]: value } }));
    } else if (name.includes('lead.')) {
      const field = name.split('.')[1];
      setForm((prev) => ({ ...prev, lead: { ...prev.lead, [field]: value } }));
    } else if (name === 'conversation') {
      setForm((prev) => ({ ...prev, conversation: [{ ...prev.conversation[0], message: value }] }));
    } else {
      setForm((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const payload = {
      tenant_id: form.tenant_id,
      lead_id: form.lead_id,
      event_id: form.event_id,
      customer: form.customer,
      lead: form.lead,
      conversation: form.conversation,
    };
    await callApi('/api/v1/webhooks/leads', 'POST', payload);
  };

  return (
    <motion.div
      className="max-w-2xl mx-auto space-y-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <h1 className="text-3xl font-bold">Webhook Simulator</h1>
      <form onSubmit={handleSubmit} className="bg-white p-6 rounded-2xl shadow-xl space-y-4">
        <div>
          <label className="block text-sm font-medium">Event ID (optional)</label>
          <input type="text" name="event_id" value={form.event_id} onChange={handleChange}
                 className="w-full px-3 py-2 border rounded-lg" />
        </div>
        <div>
          <label className="block text-sm font-medium">Lead ID</label>
          <input type="text" name="lead_id" value={form.lead_id} onChange={handleChange}
                 required className="w-full px-3 py-2 border rounded-lg" />
        </div>
        <div>
          <label className="block text-sm font-medium">Customer Name</label>
          <input type="text" name="customer.name" value={form.customer.name} onChange={handleChange}
                 required className="w-full px-3 py-2 border rounded-lg" />
        </div>
        <div>
          <label className="block text-sm font-medium">Phone</label>
          <input type="tel" name="customer.phone" value={form.customer.phone} onChange={handleChange}
                 className="w-full px-3 py-2 border rounded-lg" />
        </div>
        <div>
          <label className="block text-sm font-medium">Conversation</label>
          <input type="text" name="conversation" value={form.conversation[0]?.message}
                 onChange={(e) => setForm((p) => ({ ...p, conversation: [{ ...p.conversation[0], message: e.target.value }] }))}
                 className="w-full px-3 py-2 border rounded-lg" />
        </div>
        <motion.button
          whileTap={{ scale: 0.95 }}
          type="submit"
          disabled={loading}
          className="w-full py-3 bg-indigo-600 text-white font-semibold rounded-lg hover:bg-indigo-700 transition"
        >
          {loading ? 'Sending…' : 'Send Webhook'}
        </motion.button>
      </form>
      {error && <div className="bg-red-100 text-red-800 p-4 rounded-lg">{error}</div>}
      {data && (
        <div className="bg-green-100 text-green-800 p-4 rounded-lg">
          <p>Lead {data.lead_id} processed (Job ID: {data.job_id})</p>
        </div>
      )}
      {loading && <LoadingSpinner />}
    </motion.div>
  );
};
export default Webhook;