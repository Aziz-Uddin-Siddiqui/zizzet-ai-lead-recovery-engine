import { useState } from 'react';
import api from '../services/api';

interface UseApiOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
  body?: any;
  headers?: Record<string, string>;
}
const useApi = <T,>() => {
  const [data, setData] = useState<T | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const callApi = async (url: string, options: UseApiOptions = {}) => {
    const { method = 'GET', body, headers = {} } = options;
    setLoading(true);
    setError(null);
    try {
      let response;
      if (method === 'GET') {
        response = await api.get(url, { headers });
      } else {
        response = await api.post(url, body, { headers });
      }
      const result = response.data;
      setData(result);
      return result as T;
    } catch (err: any) {
      const msg = err.response?.data?.detail || err.message || 'An error occurred';
      setError(msg);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return { callApi, data, loading, error, setData };
};

export default useApi;