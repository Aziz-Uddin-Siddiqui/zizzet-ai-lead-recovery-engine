import { Routes, Route, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import Home from './pages/Home';
import Analyze from './pages/Analyze';
import LeadAnalysis from './pages/LeadAnalysis';
import Webhook from './pages/Webhook';
import FollowUp from './pages/FollowUp';
import './App.css';

const App: React.FC = () => (
  <div className="min-h-screen bg-gray-50 text-gray-900">
    <motion.nav
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="bg-white shadow-md p-4 flex gap-6 justify-center"
    >
      <Link to="/" className="text-indigo-600 font-semibold hover:text-indigo-800">Home</Link>
      <Link to="/analyze" className="text-indigo-600 font-semibold hover:text-indigo-800">Lead Analysis</Link>
      <Link to="/webhook" className="text-indigo-600 font-semibold hover:text-indigo-800">Webhook</Link>
    </motion.nav>

    <div className="container mx-auto p-6">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/analyze" element={<Analyze />} />
        <Route path="/lead/:leadId/analysis" element={<LeadAnalysis />} />
        <Route path="/lead/:leadId/followup" element={<FollowUp />} />
        <Route path="/webhook" element={<Webhook />} />
      </Routes>
    </div>
  </div>
);

export default App;