
### 2️⃣2️⃣ frontend/src/types.ts *(optional, for TypeScript)*
```tsx
export interface LeadAnalysisResponse {
  lead_id: string;
  lead_score: number;
  priority: string;
  intent: string;
  stage: string;
  summary: string;
  next_best_action: string;
  follow_up_channel: string;
  follow_up_message: string;
  do_not_contact: boolean;
  phone?: string;
}