"""
Mock messaging provider – logs a message instead of hitting a real API.
In a production system you would replace this with a real WhatsApp SDK,
Twilio, Meta Business API, etc.
"""

from typing import Optional
import logging

logger = logging.getLogger(__name__)

def mock_whatsapp_send(phone: Optional[str], text: str):
    """
    Simulate sending a WhatsApp message.
    """
    if not phone:
        logger.warning("mock_whatsapp_send called without a phone number")
        return
    logger.info(f"[WhatsApp Mock] To {phone}: {text}")
    # In real code you would call something like:
    # client.messages.create(to=phone, from_=CONFIG.WHATSAPP_NUMBER, body=text)

# Re‑export for convenience
__all__ = ["mock_whatsapp_send"]