import json
import logging
from typing import Dict, Any
from abc import ABC, abstractmethod

from openai import AsyncOpenAI, OpenAIError
from app.config import settings

logger = logging.getLogger(__name__)

# -----------------------------------------------------------------
# Abstract LLM interface – can be swapped for Gemini, Ollama, etc.
# -----------------------------------------------------------------
class LLMClient(ABC):
    @abstractmethod
    async def generate_recommendation(self, prompt: str) -> Dict[str, Any]:
        pass

# -----------------------------------------------------------------
# Concrete implementation – OpenAI chat completions
# -----------------------------------------------------------------
class OpenAIClient(LLMClient):
    def __init__(self):
        self.client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)

    async def generate_recommendation(self, prompt: str) -> Dict[str, Any]:
        system_msg = """
        You are an AI lead‑scoring assistant. Based on the lead data and conversation,
        output a JSON object with exactly these fields:

        {
          "lead_score": <integer 0‑100>,
          "priority": <one of "low", "medium", "high">,
          "intent": <one of "purchase", "demo", "info", "stoppage">,
          "stage": <one of "initial", "pricing_interest", "demo_requested", "stalled">,
          "summary": <string describing the lead's state>,
          "next_best_action": <string, e.g., "Send pricing and schedule a demo">,
          "follow_up_channel": <one of "whatsapp", "email", "phone", "sms">,
          "follow_up_message": <string to send to the lead>,
          "do_not_contact": <boolean – true if the lead said STOP>
        }

        If the lead says STOP, set "do_not_contact": true and keep other fields reasonable.
        Return *only* the JSON, no extra text.
        """
        try:
            resp = await self.client.chat.completions.create(
                model=settings.OPENAI_MODEL,
                messages=[
                    {"role": "system", "content": system_msg},
                    {"role": "user", "content": prompt},
                ],
                temperature=0.2,
            )
            content = resp.choices[0].message.content
            # Strip any surrounding backticks if the model wraps JSON (common)
            if content.startswith("```"):
                # simple strip of markdown code fences
                lines = content.split("\n")
                # remove first and last lines if they are fences
                if lines[0].startswith("```"):
                    lines = lines[1:]
                if lines and lines[-1].startswith("```"):
                    lines = lines[:-1]
                content = "\n".join(lines).strip()
            return json.loads(content)
        except (OpenAIError, json.JSONDecodeError, Exception) as e:
            logger.exception("LLM call failed")
            # Return a safe fallback dict so the pipeline can continue
            raise

# -----------------------------------------------------------------
# Singleton instance – used throughout the app
# -----------------------------------------------------------------
if settings.OPENAI_API_KEY:
    llm_client: LLMClient = OpenAIClient()
else:
    # Fallback mock client for testing / environments without a key
    class MockLLMClient(LLMClient):
        async def generate_recommendation(self, prompt: str) -> Dict[str, Any]:
            # Deterministic mock for testing
            prompt_lower = prompt.lower()
            if "stop" in prompt_lower:
                return {
                    "lead_score": 10,
                    "priority": "low",
                    "intent": "stoppage",
                    "stage": "stalled",
                    "summary": "Lead explicitly requested to stop.",
                    "next_best_action": "none",
                    "follow_up_channel": "whatsapp",
                    "follow_up_message": "",
                    "do_not_contact": True,
                }
            if "demo" in prompt_lower:
                return {
                    "lead_score": 85,
                    "priority": "high",
                    "intent": "demo",
                    "stage": "demo_requested",
                    "summary": "Lead asked for a demo/call.",
                    "next_best_action": "Schedule a demo call",
                    "follow_up_channel": "whatsapp",
                    "follow_up_message": "Hi! I can schedule a demo for you. When works best?",
                    "do_not_contact": False,
                }
            if "pricing" in prompt_lower or "price" in prompt_lower:
                return {
                    "lead_score": 70,
                    "priority": "medium",
                    "intent": "purchase",
                    "stage": "pricing_interest",
                    "summary": "Lead is evaluating pricing for a 25‑user team.",
                    "next_best_action": "Send pricing and schedule a demo",
                    "follow_up_channel": "whatsapp",
                    "follow_up_message": "Hi! Here is the pricing for your 25‑user requirement...",
                    "do_not_contact": False,
                }
            # Default fallback
            return {
                "lead_score": 30,
                "priority": "low",
                "intent": "info",
                "stage": "initial",
                "summary": "Lead has provided basic info.",
                "next_best_action": "Provide product overview",
                "follow_up_channel": "email",
                "follow_up_message": "Thanks for reaching out! Here is an overview of our CRM.",
                "do_not_contact": False,
            }

    llm_client = MockLLMClient()