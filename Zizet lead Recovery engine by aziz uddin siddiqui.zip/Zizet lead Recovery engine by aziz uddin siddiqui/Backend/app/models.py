from sqlalchemy import Column, Integer, String, DateTime, JSON, Boolean, ForeignKey
from sqlalchemy.orm import relationship
from datetime import datetime
from app.database import Base

class Lead(Base):
    __tablename__ = "leads"

    id = Column(Integer, primary_key=True, index=True)
    tenant_id = Column(String, index=True, nullable=False)
    lead_id = Column(String, unique=True, index=True, nullable=False)

    source = Column(String, default="unknown")
    status = Column(String, default="active")  # active, paused, closed

    created_at = Column(DateTime, default=datetime.utcnow)
    last_contacted_at = Column(DateTime, default=datetime.utcnow)

    # Relationships
    conversations = relationship("LeadConversation", back_populates="lead")
    analyses = relationship("LeadAnalysis", back_populates="lead")


class LeadConversation(Base):
    __tablename__ = "lead_conversations"

    id = Column(Integer, primary_key=True, index=True)
    lead_id = Column(String, ForeignKey("leads.lead_id"), nullable=False)
    role = Column(String, nullable=False)          # "customer" or "agent"
    message = Column(String, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow)

    lead = relationship("Lead", back_populates="conversations")


class LeadAnalysis(Base):
    __tablename__ = "lead_analyses"

    id = Column(Integer, primary_key=True, index=True)
    lead_id = Column(String, ForeignKey("leads.lead_id"), nullable=False)
    tenant_id = Column(String, index=True, nullable=False)

    # Core recommendation fields
    lead_score = Column(Integer, default=0)
    priority = Column(String, default="medium")   # low, medium, high
    intent = Column(String, default="general")    # purchase, demo, info, stoppage
    stage = Column(String, default="initial")     # initial, pricing_interest, demo_requested, stalled
    summary = Column(JSON, default=None)         # free‑form reasoning (list or dict)
    next_best_action = Column(String, default="none")
    follow_up_channel = Column(String, default="whatsapp")
    follow_up_message = Column(String, default="")
    do_not_contact = Column(Boolean, default=False)

    created_at = Column(DateTime, default=datetime.utcnow)

    lead = relationship("Lead", back_populates="analyses")


class IdempotencyKey(Base):
    __tablename__ = "idempotency_keys"

    key = Column(String, primary_key=True, unique=True)   # <event_id>_<lead_id>
    lead_id = Column(String, index=True)
    tenant_id = Column(String, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)