from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List, Optional
import asyncio

from app.database import get_db
from app.models import Lead, LeadAnalysis, LeadConversation, IdempotencyKey
from app.tasks import process_lead_analysis
from app.config import settings

router = APIRouter()

# -----------------------------------------------------------------
# Pydantic schemas (in a real project they'd live in a separate `schemas.py`)
# -----------------------------------------------------------------
from pydantic import BaseModel

class ConversationItem(BaseModel):
    role: str
    message: str

class LeadPayload(BaseModel):
    tenant_id: str
    lead_id: str
    customer: dict
    lead: dict
    conversation: List[ConversationItem]

class FollowUpResponse(BaseModel):
    lead_id: str
    follow_up_channel: str
    follow_up_message: str
    do_not_contact: bool

# -----------------------------------------------------------------
# Helper: create a deterministic idempotency key from webhook payload
# -----------------------------------------------------------------
def make_idempotency_key(event_id: Optional[str], lead_id: str, tenant_id: str) -> str:
    """
    Simple composite key – prevents duplicate processing even if the same
    lead is submitted via two different mechanisms (webhook vs /analyze).
    """
    base = f"{lead_id}_{tenant_id}"
    if event_id:
        base = f"{event_id}_{base}"
    return base

# -----------------------------------------------------------------
# 1️⃣ POST /api/v1/leads/analyze
# -----------------------------------------------------------------
@router.post("/leads/analyze")
async def analyze_lead(
    payload: LeadPayload,
    db: AsyncSession = Depends(get_db),
    background_tasks: BackgroundTasks = None,
):
    tenant_id = payload.tenant_id
    lead_id = payload.lead_id

    # ---- Tenant isolation – find existing lead (if any) ----
    stmt = select(Lead).where(Lead.tenant_id == tenant_id, Lead.lead_id == lead_id)
    result = await db.execute(stmt)
    lead = result.scalar_one_or_none()

    if not lead:
        # Create new lead record
        lead = Lead(
            tenant_id=tenant_id,
            lead_id=lead_id,
            source=payload.lead.get("source", "unknown"),
            status=payload.lead.get("status", "active"),
            created_at=payload.lead.get("created_at"),
            last_contacted_at=payload.lead.get("last_contacted_at"),
        )
        db.add(lead)
        await db.flush()   # now lead.id is available

        # Store conversation messages
        for msg in payload.conversation:
            conv = LeadConversation(
                lead_id=lead_id,
                role=msg.role,
                message=msg.message,
            )
            db.add(conv)

    # ---- Idempotency (simple – based on lead_id + tenant) ----
    idemp_key = make_idempotency_key(event_id=None, lead_id=lead_id, tenant_id=tenant_id)
    stmt_key = select(IdempotencyKey).where(IdempotencyKey.key == idemp_key)
    key_result = await db.execute(stmt_key)
    existing = key_result.scalar_one_or_none()

    if existing:
        # Duplicate request – return the *existing* analysis if already done
        # For simplicity we raise a conflict; you could also just return the existing result.
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Processing already in progress or completed",
        )

    # Store idempotency marker
    idemp_obj = IdempotencyKey(key=idemp_key, lead_id=lead_id, tenant_id=tenant_id)
    db.add(idemp_obj)

    # ---- Create a pending analysis record ----
    analysis = LeadAnalysis(
        lead_id=lead_id,
        tenant_id=tenant_id,
        # The background task will fill the rest
        intent="general",
        stage="initial",
        summary="Initial analysis requested.",
        do_not_contact=False,
    )
    db.add(analysis)
    await db.flush()   # analysis.id now exists

    # ---- Trigger background processing ----
    # Using asyncio.create_task so the HTTP response is immediate.
    # In production you would push to a proper job queue (Redis, RabbitMQ, etc.)
    if settings.QUEUE_ENABLED:
        asyncio.create_task(
            process_lead_analysis(
                job_id=analysis.id,
                lead_id=lead_id,
                tenant_id=tenant_id,
            )
        )

    return {
        "lead_id": lead_id,
        "job_id": analysis.id,
        "status": "queued_for_processing",
    }

# -----------------------------------------------------------------
# 2️⃣ GET /api/v1/leads/{lead_id}/analysis
# -----------------------------------------------------------------
@router.get("/leads/{lead_id}/analysis")
async def get_lead_analysis(
    lead_id: str,
    tenant_id: str,               # we ask the caller to provide tenant (e.g., from auth header)
    db: AsyncSession = Depends(get_db),
):
    # Strict tenant isolation
    stmt = select(LeadAnalysis).where(
        LeadAnalysis.lead_id == lead_id,
        LeadAnalysis.tenant_id == tenant_id,
    )
    result = await db.execute(stmt)
    analysis = result.scalar_one_or_none()

    if not analysis:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Lead analysis not found",
        )

    # Return the most recent (or only) analysis
    return {
        "lead_id": analysis.lead_id,
        "lead_score": analysis.lead_score,
        "priority": analysis.priority,
        "intent": analysis.intent,
        "stage": analysis.stage,
        "summary": analysis.summary,
        "next_best_action": analysis.next_best_action,
        "follow_up_channel": analysis.follow_up_channel,
        "follow_up_message": analysis.follow_up_message,
        "do_not_contact": analysis.do_not_contact,
    }

# -----------------------------------------------------------------
# 3️⃣ POST /api/v1/leads/{lead_id}/follow-up
# -----------------------------------------------------------------
@router.post("/leads/{lead_id}/follow-up")
async def generate_follow_up(
    lead_id: str,
    tenant_id: str,
    db: AsyncSession = Depends(get_db),
):
    # Find the latest analysis (same logic as GET)
    stmt = select(LeadAnalysis).where(
        LeadAnalysis.lead_id == lead_id,
        LeadAnalysis.tenant_id == tenant_id,
    )
    result = await db.execute(stmt)
    analysis = result.scalar_one_or_none()

    if not analysis:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="No analysis found for this lead",
        )

    # Respect the do_not_contact flag
    if analysis.do_not_contact:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Customer has opted out (do_not_contact=true)",
        )

    # -----------------------------------------------------------------
    # In a real system you would call the messaging service here.
    # For this demo we only log the message.
    # -----------------------------------------------------------------
    from app.services.messaging_service import mock_whatsapp_send
    mock_whatsapp_send(
        phone=analysis.phone,   # <‑‑ we need phone – it's stored in Lead.customer JSON.
        text=analysis.follow_up_message,
    )

    return FollowUpResponse(
        lead_id=lead_id,
        follow_up_channel=analysis.follow_up_channel,
        follow_up_message=analysis.follow_up_message,
        do_not_contact=analysis.do_not_contact,
    )