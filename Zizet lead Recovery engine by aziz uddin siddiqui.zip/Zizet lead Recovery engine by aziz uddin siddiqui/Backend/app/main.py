from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
import uvicorn
from app.api import router
from app.config import settings

app = FastAPI(
    title=settings.APP_NAME,
    debug=settings.DEBUG,
    openapi_url="/api/v1/openapi.json",
)

# Include all lead‑related routes under /api/v1
app.include_router(router, prefix="/api/v1")

# Simple health check endpoint (optional for load balancers)
@app.get("/health", status_code=200)
def health():
    return {"status": "ok"}

# Global exception handler (optional – keeps responses uniform)
@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException):
    return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})

if __name__ == "__main__":
    # This block is used when running `python -m app.main` locally
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.DEBUG,
    )