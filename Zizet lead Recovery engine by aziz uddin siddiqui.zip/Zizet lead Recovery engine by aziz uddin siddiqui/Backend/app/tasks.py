import asyncio
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import AsyncSessionLocal
from app.models import Lead, LeadAnalysis, LeadConversation
from app.services.llm_service import llm_client   # shared LLM client instance
from app.config import settings

async def process_lead_analysis(job_id: int, lead_id: str, tenant_id: str):
    """
    Background worker – called from the API when a new lead is submitted.
    Fetches the lead & conversation, asks the LLM for a recommendation,
    and writes the structured result back into the LeadAnalysis table.
    """
    # ---- Load the lead record ----
    async with AsyncSessionLocal() as session:
        lead_stmt = select(Lead).where(Lead.lead_id == lead_id, Lead.tenant_id == tenant_id)
        lead_result = await session.execute(lead_stmt)
        lead = lead_result.scalar_one_or_none()
        if not lead:
            print(f"[Worker] Lead {lead_id} not found – aborting job {job_id}")
            return

        # ---- Load conversation ----
        conv_stmt = select(LeadConversation).where(LeadConversation.lead_id == lead_id)
        conv_result = await session.execute(conv_stmt)
        conversations = conv_result.scalars().all()

        # Build a prompt the LLM can understand
        prompt_parts = [
            f"Tenant: {tenant_id}",
            f"Lead source: {lead.source}",
            f"Lead status: {lead.status}",
            "Recent conversation:"
        ]
        for c in conversations:
            prompt_parts.append(f"{c.role}: {c.message}")
        prompt = "\n".join(prompt_parts)

        # ---- Call LLM (mock in tests, real OpenAI in prod) ----
        try:
            recommendation = await llm_client.generate_recommendation(prompt)
        except Exception as e:
            # If the LLM fails, we keep the existing placeholder values
            print(f"[Worker] LLM error for lead {lead_id}: {e}")
            recommendation = {
                "lead_score": 0,
                "priority": "medium",
                "intent": "general",
                "stage": "initial",
                "summary": f"LLM failed: {e}",
                "next_best_action": "none",
                "follow_up_channel": "whatsapp",
                "follow_up_message": "",
                "do_not_contact": False,
            }

        # ---- Update the analysis row ----
        analysis_stmt = select(LeadAnalysis).where(LeadAnalysis.id == job_id)
        analysis_result = await session.execute(analysis_stmt)
        analysis = analysis_result.scalar_one_or_none()
        if not analysis:
            print(f"[Worker] Analysis record {job_id} missing")
            return

        # Apply recommendation
        analysis.lead_score = recommendation.get("lead_score", 0)
        analysis.priority = recommendation.get("priority", "medium")
        analysis.intent = recommendation.get("intent", "general")
        analysis.stage = recommendation.get("stage", "initial")
        analysis.summary = recommendation.get("summary")
        analysis.next_best_action = recommendation.get("next_best_action", "none")
        analysis.follow_up_channel = recommendation.get("follow_up_channel", "whatsapp")
        analysis.follow_up_message = recommendation.get("follow_up_message", "")
        analysis.do_not_contact = recommendation.get("do_not_contact", False)

        await session.commit()
        print(f"[Worker] Completed analysis for lead {lead_id} (job {job_id})")