from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    # Database – PostgreSQL preferred, SQLite works for dev
    DATABASE_URL: str = "postgresql+asyncpg://postgres:postgres@localhost/zizzet_db"

    # OpenAI configuration (you can plug in Gemini / Ollama here)
    OPENAI_API_KEY: str = ""
    OPENAI_MODEL: str = "gpt-4o"

    # Misc
    APP_NAME: str = "Zizzet Lead Recovery Engine"
    DEBUG: bool = True
    QUEUE_ENABLED: bool = True

    class Config:
        env_file = ".env"
        case_sensitive = False

settings = Settings()