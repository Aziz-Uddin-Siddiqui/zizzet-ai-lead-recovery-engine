import pytest
from fastapi import status
import json

def test_webhook_leads_idempotent(client):
    """
    POST /api/v1/webhooks/leads twice → only one background job.
    """
    payload = {
        "tenant_id": "t3",
        "lead_id": "lead_003",
        "event_id": "evt_123",   # unique identifier for this webhook
        "customer": {"name": "Charlie"},
        "lead": {"source": "form", "status": "new"},
        "conversation": [
            {"role": "customer", "message": "I want a demo."}
        ]
    }

    # First webhook
    resp1 = client.post("/api/v1/webhooks/leads", json=payload)
    assert resp1.status_code == status.HTTP_200_OK
    data1 = resp1.json()
    assert data1["lead_id"] == "lead_003"
    assert data1["job_id"] is not None

    # Second identical webhook (same event_id) → should be idempotent
    resp2 = client.post("/api/v1/webhooks/leads", json=payload)
    # Our implementation returns 409 Conflict when the same event_id is seen again
    assert resp2.status_code == status.HTTP_409_CONFLICT
    assert "already processed" in resp2.json()["detail"].lower()

def test_webhook_stop_handling(client):
    """
    Webhook with a customer saying STOP should set do_not_contact=true.
    """
    payload = {
        "tenant_id": "t4",
        "lead_id": "lead_004",
        "event_id": "evt_456",
        "customer": {"name": "Dana"},
        "lead": {"source": "chat", "status": "contacted"},
        "conversation": [
            {"role": "customer", "message": "STOP. Don't message me again."}
        ]
    }

    resp = client.post("/api/v1/webhooks/leads", json=payload)
    assert resp.status_code == status.HTTP_200_OK
    # Verify that the analysis record indicates do_not_contact (mocked in llm_service)
    # For brevity we just check the response shape
    data = resp.json()
    assert data["lead_id"] == "lead_004"
    assert data.get("do_not_contact") == True