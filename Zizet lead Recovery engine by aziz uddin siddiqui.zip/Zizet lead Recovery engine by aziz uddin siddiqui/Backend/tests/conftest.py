import asyncio
import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

# Use an in‑memory SQLite DB for tests (fast & isolated)
TEST_DATABASE_URL = "sqlite+aiosqlite:///:memory:"

# Engine & session factory
_test_engine = create_async_engine(TEST_DATABASE_URL)
_test_session_factory = sessionmaker(_test_engine, class_=AsyncSession, expire_on_commit=False)

@pytest.fixture(scope="function")
async def db_session():
    """
    Provide a fresh async DB session for each test.
    Automatically creates tables (via Base.metadata.create_all).
    """
    async with _test_session_factory() as session:
        # Import models here to avoid circular imports
        from app.models import Base
        async with _test_engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        yield session
        await session.flush()
        await session.close()

@pytest.fixture
def client(db_session):
    """
    FastAPI TestClient that overrides the real `get_db` dependency.
    """
    from app.main import app
    from app.database import get_db

    async def override_get_db():
        # Return the test session directly
        async with _test_session_factory() as session:
            yield session

    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c