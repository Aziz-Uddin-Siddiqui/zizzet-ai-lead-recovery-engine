import pytest
from fastapi import status
from app.models import Lead, LeadAnalysis, LeadConversation

def test_analyze_lead_success(client):
    """
    Happy‑path test for the /analyze endpoint.
    """
    payload = {
        "tenant_id": "t1",
        "lead_id": "lead_001",
        "customer": {"name": "Alice", "phone": "+1234567890"},
        "lead": {
            "source": "whatsapp",
            "status": "contacted",
            "created_at": "2026-01-01T00:00:00",
            "last_contacted_at": "2026-01-02T00:00:00"
        },
        "conversation": [
            {"role": "customer", "message": "I need a CRM for 30 users."},
            {"role": "agent", "message": "Sure! What features do you need?"}
        ]
    }

    # POST /api/v1/leads/analyze
    resp = client.post("/api/v1/leads/analyze", json=payload)
    assert resp.status_code == status.HTTP_200_OK, resp.json()
    data = resp.json()
    assert data["lead_id"] == "lead_001"
    assert data["status"] == "queued_for_processing"
    assert "job_id" in data

    # The background job would have populated LeadAnalysis (mocked in llm_service)
    # For this test we just verify that the DB row exists (optional)
    # (Here we trust the mock LLM and skip actual DB check for brevity)

def test_analyze_missing_fields(client):
    """
    Bad request when required fields are missing.
    """
    payload = {"tenant_id": "t1"}  # missing lead_id, etc.
    resp = client.post("/api/v1/leads/analyze", json=payload)
    assert resp.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY  # Pydantic validation error

def test_analyze_idempotency(client):
    """
    Submitting the same payload twice should be idempotent (same job_id).
    """
    payload = {
        "tenant_id": "t2",
        "lead_id": "lead_002",
        "customer": {"name": "Bob", "phone": "+1987654321"},
        "lead": {
            "source": "email",
            "status": "new",
            "created_at": "2026-01-01T00:00:00",
            "last_contacted_at": None
        },
        "conversation": [
            {"role": "customer", "message": "STOP. Don't contact me."}
        ]
    }

    # First call
    resp1 = client.post("/api/v1/leads/analyze", json=payload)
    assert resp1.status_code == status.HTTP_200_OK
    job_id1 = resp1.json()["job_id"]

    # Second call – expect same job (idempotent)
    resp2 = client.post("/api/v1/leads/analyze", json=payload)
    # In our implementation we raise 409 because a IdempotencyKey already exists
    # (you could also return the existing job – choose whichever you prefer)
    assert resp2.status_code == status.HTTP_409_CONFLICT
    assert resp2.json()["detail"] == "Processing already in progress or completed"