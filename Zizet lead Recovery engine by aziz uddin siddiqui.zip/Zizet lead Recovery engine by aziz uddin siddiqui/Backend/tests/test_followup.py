import pytest
from fastapi import status

def test_generate_follow_up_success(client):
    """
    Generate a follow‑up for a lead that has analysis.
    """
    # First create a lead (via /analyze) – this also creates an analysis via the mock LLM
    payload = {
        "tenant_id": "t5",
        "lead_id": "lead_005",
        "customer": {"name": "Eve", "phone": "+1112223333"},
        "lead": {
            "source": "whatsapp",
            "status": "contacted",
            "created_at": "2026-01-01T00:00:00",
            "last_contacted_at": "2026-01-02T00:00:00"
        },
        "conversation": [
            {"role": "customer", "message": "I need pricing for 10 users."}
        ]
    }

    resp = client.post("/api/v1/leads/analyze", json=payload)
    assert resp.status_code == status.HTTP_200_OK
    # The mock LLM will return a recommendation; we can just call follow-up endpoint

    follow_up_resp = client.post("/api/v1/leads/lead_005/follow-up")
    assert follow_up_resp.status_code == status.HTTP_200_OK
    fu = follow_up_resp.json()
    assert fu["lead_id"] == "lead_005"
    assert fu["follow_up_channel"] == "whatsapp"
    assert fu["follow_up_message"] is not None
    # The mock WhatsApp service only logs – we just verify the response shape

def test_follow_up_when_do_not_contact(client):
    """
    If do_not_contact is true, follow‑up must be rejected.
    """
    # Create a lead that the mock LLM will mark as do_not_contact
    payload = {
        "tenant_id": "t6",
        "lead_id": "lead_006",
        "customer": {"name": "Frank"},
        "lead": {"source": "email", "status": "new"},
        "conversation": [
            {"role": "customer", "message": "STOP."}
        ]
    }

    client.post("/api/v1/leads/analyze", json=payload)

    resp = client.post("/api/v1/leads/lead_006/follow-up")
    # Our endpoint should return 400 Bad Request
    assert resp.status_code == status.HTTP_400_BAD_REQUEST
    assert "do_not_contact" in resp.json()["detail"].lower()