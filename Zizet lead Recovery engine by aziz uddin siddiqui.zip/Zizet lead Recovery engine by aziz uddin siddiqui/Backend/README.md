# Zizzet AI Lead Recovery Engine

A minimal, production‑oriented FastAPI service that turns lead & conversation data into a structured recovery recommendation.

## 🚀 Quick Start (Local Development)

1. **Install Docker & Docker‑Compose** (optional – use native Python if you prefer).
2. **Start the stack**  
   ```bash
   docker-compose up --build